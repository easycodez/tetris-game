$j = jQuery.noConflict();
$j(document).ready(function () {
    let id = null;
    const xSpeed = 8;
    const ySpeed = 0.4;
    let speedupYSpeed = false;
    let blockWidth = 50;
    let occupiedPostions = {};
    let firstBlockPosition = 400 + getCoordinates($j('.game-area .block').first()[0]) + 1;
    let gameAreaWidth = $j('.game-area').width();
    let gameAreaOffsetLeft = $j('.game-area').offset().left;
    let gameAreaOffsetTop = $j('.game-area').offset().top;
    let maxBlocksX = parseInt(gameAreaWidth / blockWidth);


    let gameOver = false;

    var gameVM = function () {
        var self = this;
        this.newBlocks = ko.observableArray([]);
        this.isNewBlock = ko.observable(true);
        this.posValue = firstBlockPosition;
        this.toggleGameState = ko.observable(true);
        this.fallDown = function (e, i, data) {
            moveDown(e);
            $j(e).focus();
        }
        this.start = function (e) {
            //console.log('start game');
            if (!gameOver)
                self.newBlocks.push([]);
        }
        this.pause = function () {
            clearInterval(id);
        }
        this.onKeydown = function (data, e) {

            if (gameOver) {
                return;
            }
            if (e.which == 37) { //left arr
                moveLeft(e);
            } else if (e.which == 39) { //right arr
                moveRight(e);
            } else if (e.which == 40) { //down arr
                speedupYSpeed = 0.4;
            } else if (e.which == 32) { //space
                self.toggleGameState(!self.toggleGameState());
                toggleGameState();
            }
            //  
        }
        this.onKeyup = function (data, e) {
            speedupYSpeed = false;
        }
    }
    var gameVMObject = new gameVM();
    ko.applyBindings(gameVMObject);

    function moveDown(e) {
        const elem = e;
        let posTop = elem.getBoundingClientRect().top;
        let posLeft = elem.getBoundingClientRect().left;

        let bottomStopPoint = 400 + $j('.game-area').offset().top - blockWidth + 1;
        clearInterval(id);
        id = setInterval(frame, 5);
        function frame() {

            if (posTop > bottomStopPoint) {
                stopMoveDown(e, posTop);
            } else if (!bottomPostionAvailabe(e, posTop)) {
                stopMoveDown(e, posTop);
                console.log("bottom pos not available --stopped");
                console.log(e);
            } else {
                posTop = posTop + ySpeed;
                if (speedupYSpeed != false) {
                    posTop = posTop + speedupYSpeed;
                }
                try {
                    elem.style.top = posTop + 'px';
                    elem.style.left = posLeft + 'px';

                    elem.setAttribute('data-pos', parseInt(posTop));
                    var col = getBlockCol(elem);
                    elem.setAttribute('data-col', col);

                    var possibleCols = getBlockPossibleCol(elem);
                    elem.setAttribute('data-possiblecols', possibleCols);

                    let row = getBlockRow(elem);
                    elem.setAttribute('data-row', row);

                    let possibleRows = getBlockPossibleRow(e);
                    elem.setAttribute('data-possiblerow', possibleRows);

                } catch (exc) {
                    console.log(exc);
                    clearInterval(id);
                }
            }
        }
    }
    function moveRight(e) {
        clearInterval(id);
        var elem = e.target;
        let blockPosRight = elem.getBoundingClientRect().left;
        let gameArea = $j('.game-area').width();
        let rightSpace = (gameArea + gameAreaOffsetLeft) - blockPosRight - blockWidth - (xSpeed * 1); //game area right

        var nearestRightBlock = getNearestBlock(elem, 'right');

        if (rightSpace > 0 && nearestRightBlock != false) {
            var speed = xSpeed;
            if (nearestRightBlock.length > 0) {
                var spaceFromRightBlocker = Math.abs(blockPosRight - nearestRightBlock[0].getBoundingClientRect().left);
                if (Math.abs(spaceFromRightBlocker - xSpeed) < blockWidth) {
                    speed = Math.abs(spaceFromRightBlocker - blockWidth);
                }
            }
            elem.style.left = (blockPosRight + speed) + 'px';
            let latestCol = getBlockCol(elem);
//            console.log(latestCol);
            elem.setAttribute('data-col', latestCol);
        }

        moveDown(elem);
    }
    function moveLeft(e) {
        clearInterval(id);
        var elem = e.target;
        let blockPosLeft = elem.getBoundingClientRect().left;
        let  gameAreaOffsetLeft = $j('.game-area').offset().left;
        let leftSpace = blockPosLeft - gameAreaOffsetLeft;
        var nearestLeftBlock = getNearestBlock(elem, 'left');
        if (leftSpace > 0 && nearestLeftBlock !== false) {
            var speed = xSpeed;
            let spaceFromLeftBlocker = 0;
            if (nearestLeftBlock.length > 0) {
                spaceFromLeftBlocker = Math.abs(blockPosLeft - nearestLeftBlock[0].getBoundingClientRect().left);
                if (Math.abs(spaceFromLeftBlocker - xSpeed) <= blockWidth) {
                    speed = Math.abs(spaceFromLeftBlocker - blockWidth);
                }
            }
            elem.style.left = (blockPosLeft - speed) + 'px';
            let latestCol = getBlockCol(elem);
            console.log(latestCol);
            elem.setAttribute('data-col', latestCol);

            console.log("==start leftblcok gap====");
            console.log(elem);
            console.log(nearestLeftBlock);
            console.log("moved left by=" + (blockPosLeft - speed));
            console.log("spaceFromLeftBlocker=" + spaceFromLeftBlocker);
            console.log("==end leftblcok gap");
        }
        // moveDown(elem);
    }

    function stopMoveDown(elem, posTop) {

        clearInterval(id);
        let corodinate = getCoordinates(elem);
        occupiedPostions[corodinate] = 1;

        if (Math.abs(elem.getBoundingClientRect().top - $j('.game-area').offset().top) > blockWidth) {
            startNewBlock(elem);
        } else {
            finishGame();
        }
        ;
    }
    function bottomPostionAvailabe(elem, currTopPos) {

        let tc = getThresoldCoordinates(elem); //bottom block

        if (occupiedPostions[tc] != null) { // top condition met

            try {
                var bottomBlockElem = $j('[data-pos="' + (tc + blockWidth) + '"]');
                var currentElemCol = elem.getAttribute('data-col');
                var bottomBlock = bottomBlockElem.filter('[data-col="' + currentElemCol + '"]').first();
                if (bottomBlock.length == 0) {
                    var possiblecols = elem.getAttribute('data-possiblecols');
                    bottomBlock = bottomBlockElem.filter('[data-col="' + possiblecols + '"]').first();
                    if (bottomBlock.length == 0) {
                        bottomBlock = bottomBlockElem.filter('[data-col="' + (currentElemCol - 1) + '"]').first();
                        if (bottomBlock.length == 0) {
                            //console.log("no match bottomBlock");
                            //console.log(elem);
                            bottomBlock = bottomBlockElem.first();
                            //console.log(bottomBlock);
                        }
                    }
                }
//                //console.log(bottomBlock);
                var nearestLastBlockLeft = bottomBlock.offset().left;
                var currBlockLeft = $j(elem).offset().left;

                if (bottomBlock.offset().top < 200) {
                    console.error("Game over!!!!!");
                }

                var touched = currBlockLeft - nearestLastBlockLeft;
//                console.log("====start======");
//                console.log("touch point =" + touched);
//                console.log($j(elem));
//                console.log(bottomBlock);
//                console.log("====end======");

                /** is nearest bottom block gap more than 50 then return true for movedown */
                if (Math.abs(touched) > blockWidth) {
                    console.log("not toched !!!!!!!!!");
                    return true;
                }
            } catch (e) {

            }

            return false;
        }

        return true;
    }

    function getCoordinates(elem) {
        let posTop = elem.getBoundingClientRect().top - blockWidth;
        posTop = parseInt(posTop);
        return posTop;
    }
    function getThresoldCoordinates(elem) {
        let posTop = elem.getBoundingClientRect().top;
        posTop = parseInt(posTop);
        return posTop;
    }

    function startNewBlock(prevBlockElem) {
        gameVMObject.start();
    }
    function finishGame() {
        clearInterval(id);
        $j('.status').html("Game over!!");
        gameOver = true;
    }

    function getBlockCol(e) {
        let posLeft = e.getBoundingClientRect().left;
        var colFloat = (posLeft - gameAreaOffsetLeft) / blockWidth;
        colFloat = colFloat <= 0 ? 1 : colFloat;
        var col = parseInt(colFloat);
        col = colFloat > col ? col + 1 : col;
        return col;
    }
    function getBlockPossibleCol(e) {
        let posLeft = e.getBoundingClientRect().left;
        var possibleColsFloat = (posLeft - gameAreaOffsetLeft + blockWidth) / blockWidth;
        var possibleCols = parseInt(possibleColsFloat);
        possibleCols = possibleColsFloat > possibleCols ? possibleCols + 1 : possibleCols;
        return possibleCols;
    }
    function getBlockRow(e) {
        let posTop = e.getBoundingClientRect().top;
        var rowFloat = (posTop - gameAreaOffsetTop) / blockWidth;
        var row = parseInt(rowFloat);
        row = rowFloat > row ? row + 1 : row;
        return row;
    }
    function getBlockPossibleRow(e) {
        let posTop = e.getBoundingClientRect().top;
        var rowFloat = (posTop - gameAreaOffsetTop + blockWidth) / blockWidth;
        var row = parseInt(rowFloat);
        row = rowFloat > row ? row + 1 : row;
        return row;
    }
    function getNearestBlock(elem, side) {

        var sideSpace = true;
        var theSide = side == 'left' ? -1 : +1;

        var col = elem.getAttribute('data-col');
        var row = elem.getAttribute('data-row');
        var possiblerow = elem.getAttribute('data-possiblerow');
        let blockPosRight = elem.getBoundingClientRect().left;

        col = parseInt(col);
        row = parseInt(row);
        possiblerow = parseInt(possiblerow);

        var nearestRightBlockCol = col + theSide;
        if (nearestRightBlockCol <= 0) {
            nearestRightBlockCol = 1;
        }

        var nearestRightBlock = $j('[data-col="' + nearestRightBlockCol + '"]').not(".newblock");
        var spaceFromRightBlocker = 50;
        if (nearestRightBlock.length > 0) {
            var nearestRightBlock = nearestRightBlock.filter('[data-row="' + (row) + '"]');

            if (nearestRightBlock.length == 0) {
                nearestRightBlock = $j('[data-col="' + (col + theSide) + '"]').not(".newblock").filter('[data-row="' + (possiblerow) + '"]');
            }

            if (nearestRightBlock.length > 0) {
                spaceFromRightBlocker = Math.abs(blockPosRight - nearestRightBlock[0].getBoundingClientRect().left);
                if (spaceFromRightBlocker <= 50) {
                    console.log("spaceFromRightBlocker=" + spaceFromRightBlocker);
                    sideSpace = false;
                }
            }
        }

        return !sideSpace ? sideSpace : nearestRightBlock;
    }

    /**
     * continue/pause game
     * @returns {undefined}
     */
    function toggleGameState() {
        if (gameVMObject.toggleGameState()) {
            var newBlock = $j('.newblock');
            if (newBlock.length > 0) {
                moveDown(newBlock[0]);
            }
        } else {
            clearTimeout(id);
        }
    }



});