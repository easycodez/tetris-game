$j = jQuery.noConflict();
$j(document).ready(function () {
    let id = null;
    const xSpeed = 8;
    const ySpeed = 0.4;
    let occupiedPostions = {};
    let gameAreaOffsetTop = 400 + getCoordinates($j('.game-area .block').first()[0]) + 1;
    let gameAreaWidth = $j('.game-area').width();
    let gameAreaOffsetLeft = $j('.game-area').offset().left;
    let maxBlocksX = parseInt(gameAreaWidth / 50);
    let gameOver = false;

    var gameVM = function () {
        var self = this;
        this.newBlocks = ko.observableArray([]);
        this.isNewBlock = ko.observable(true);
        this.posValue = gameAreaOffsetTop;
        this.fallDown = function (e, i, data) {
            moveDown(e);
            $j(e).focus();
        }
        this.start = function (e) {
            //console.log('start game');
            if (!gameOver)
                self.newBlocks.push([]);
        }
        this.pause = function () {
            clearInterval(id);
        }
        this.moveBlockKeyDown = function (data, e) {
            if (gameOver) {
                return;
            }
            if (e.which == 37) { //left arr
                moveLeft(e);
            } else if (e.which == 39) { //right arr
                moveRight(e);
            }
        }
    }
    var gameVMObject = new gameVM();
    ko.applyBindings(gameVMObject);

    function moveDown(e) {
        const elem = e;
        let posTop = elem.getBoundingClientRect().top;
        let posLeft = elem.getBoundingClientRect().left;

        let bottomStopPoint = 400 + $j('.game-area').offset().top - 50 + 1;
        clearInterval(id);
        id = setInterval(frame, 5);
        function frame() {

            if (posTop > bottomStopPoint) {
                stopMoveDown(e, posTop);
            } else if (!bottomPostionAvailabe(e, posTop)) {
                stopMoveDown(e, posTop);
            } else {
                posTop = posTop + ySpeed;
                try {
                    elem.style.top = posTop + 'px';
                    elem.style.left = posLeft + 'px';
                    elem.setAttribute('data-pos', parseInt(posTop));
                    var blockWidth = e.getBoundingClientRect().width;
                    var colFloat = (posLeft - gameAreaOffsetLeft) / blockWidth;
                    colFloat = colFloat == 0 ? 1 : colFloat;
                    var col = parseInt(colFloat);
                    col = colFloat > col ? col + 1 : col;
                    elem.setAttribute('data-col', col);

                    var possibleColsFloat = (posLeft - gameAreaOffsetLeft + 50) / blockWidth;
                    var possibleCols = parseInt(possibleColsFloat);
                    possibleCols = possibleColsFloat > possibleCols ? possibleCols + 1 : possibleCols;
                    elem.setAttribute('data-possiblecols', possibleCols);

                } catch (exc) {
                    console.log(exc);
                    clearInterval(id);
                }
            }
        }
    }
    function moveRight(e) {
        clearInterval(id);
        var elem = e.target;
        let blockPosLeft = elem.getBoundingClientRect().left;
        let gameArea = $j('.game-area').width();
        let rightSpace = (gameArea + gameAreaOffsetLeft) - blockPosLeft - 50 - (xSpeed * 1); //game area right


        if (rightSpace > 0) {
            elem.style.left = (blockPosLeft + xSpeed) + 'px';
        }
        moveDown(elem);

    }
    function moveLeft(e) {
        clearInterval(id);
        var elem = e.target;
        let blockPosLeft = elem.getBoundingClientRect().left;
        let  gameAreaOffsetLeft = $j('.game-area').offset().left;
        let leftSpace = blockPosLeft - gameAreaOffsetLeft;


        var blockerCol = elem.getAttribute('data-col');
        console.log("blockerCol=" + blockerCol);
        var possibleBlockerCol = elem.getAttribute('data-possiblecols');
        var leftBlocker = $j('[data-col="' + (blockerCol - 1) + '"]');

        var spaceFromLeftBlocker = 100;
        var topSpaceBetweenCurrBlockAndLeftBlocker = 100;
        if (leftBlocker.length > 0) {

            spaceFromLeftBlocker = Math.abs(blockPosLeft - leftBlocker[0].getBoundingClientRect().left);
            topSpaceBetweenCurrBlockAndLeftBlocker = Math.abs(elem.getAttribute('data-pos')
                    - leftBlocker[0].getAttribute('data-pos') - 50);
            console.log("=========1 satart=============");
            console.log(elem);
            console.log(leftBlocker);
            console.log("spaceFromLeftBlocker=" + spaceFromLeftBlocker);
            console.log("topSpaceBetweenCurrBlockAndLeftBlocker=" + topSpaceBetweenCurrBlockAndLeftBlocker);
            console.log("==========1 end============");
            if (spaceFromLeftBlocker <= 50 && topSpaceBetweenCurrBlockAndLeftBlocker <= 0) {
                leftSpace = 0;
            }
        }
        if (leftSpace > 0) {
            elem.style.left = (blockPosLeft - xSpeed) + 'px';
        }
        moveDown(elem);
    }

    function stopMoveDown(elem, posTop) {

        clearInterval(id);
        let corodinate = getCoordinates(elem);
        occupiedPostions[corodinate] = 1;

        if (Math.abs(elem.getBoundingClientRect().top - $j('.game-area').offset().top) > 50) {
            startNewBlock(elem);
        } else {
            finishGame();
        }
        ;
    }
    function bottomPostionAvailabe(elem, currTopPos) {

        let tc = getThresoldCoordinates(elem); //bottom block

        if (occupiedPostions[tc] != null) { // top condition met

            try {
                var bottomBlockElem = $j('[data-pos="' + (tc + 50) + '"]');
                var currentElemCol = elem.getAttribute('data-col');
                var bottomBlock = bottomBlockElem.filter('[data-col="' + currentElemCol + '"]').first();
                if (bottomBlock.length == 0) {
                    var possiblecols = elem.getAttribute('data-possiblecols');
                    bottomBlock = bottomBlockElem.filter('[data-col="' + possiblecols + '"]').first();
                    if (bottomBlock.length == 0) {
                        bottomBlock = bottomBlockElem.filter('[data-col="' + (currentElemCol - 1) + '"]').first();
                        if (bottomBlock.length == 0) {
                            //console.log("no match bottomBlock");
                            //console.log(elem);
                            bottomBlock = bottomBlockElem.first();
                            //console.log(bottomBlock);
                        }
                    }
                }
//                //console.log(bottomBlock);
                var nearestLastBlockLeft = bottomBlock.offset().left;
                var currBlockLeft = $j(elem).offset().left;

                if (bottomBlock.offset().top < 200) {
                    console.error("Game over!!!!!");
                }

                var touched = currBlockLeft - nearestLastBlockLeft;
                //console.log("touched=" + touched);
                if (Math.abs(touched) > 50) {
                    //console.log("toched tru");
                    return true;
                }
            } catch (e) {

            }

            return false;
        }

        return true;
    }

    function getCoordinates(elem) {
        let posTop = elem.getBoundingClientRect().top - 50;
        posTop = parseInt(posTop);
        return posTop;
    }
    function getThresoldCoordinates(elem) {
        let posTop = elem.getBoundingClientRect().top;
        posTop = parseInt(posTop);
        return posTop;
    }

    function startNewBlock(prevBlockElem) {
        gameVMObject.start();
    }
    function finishGame() {
        clearInterval(id);
        $j('.status').html("Game over!!");
        gameOver = true;
    }
});